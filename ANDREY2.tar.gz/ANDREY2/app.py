import sqlite3
from datetime import datetime

# --- CONFIGURAÇÃO DO BANCO DE DADOS ---
def init_db():
    """Cria o banco de dados e as tabelas se não existirem."""
    conn = sqlite3.connect('sisvenda.db')
    cursor = conn.cursor()
    
    # Tabela de Usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
    # Tabela de Clientes
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf TEXT UNIQUE
        )
    ''')
    
    # Tabela de Produtos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            estoque INTEGER NOT NULL
        )
    ''')
    
    # Tabela de Vendas
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vendas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            produto_id INTEGER,
            quantidade INTEGER,
            total REAL,
            data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_id) REFERENCES clientes(id),
            FOREIGN KEY(produto_id) REFERENCES produtos(id)
        )
    ''')
    
    # Criar usuário padrão (admin / admin123)
    try:
        cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", ('admin', 'admin123'))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
        
    conn.close()

# --- FUNÇÕES DE APOIO ---
def conectar():
    return sqlite3.connect('sisvenda.db')

def login():
    print("\n" + "="*20)
    print("  LOGIN SISVENDA")
    print("="*20)
    user = input("Usuário: ")
    senha = input("Senha: ")
    
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE username = ? AND password = ?", (user, senha))
    usuario = cursor.fetchone()
    conn.close()
    return usuario is not None

# --- OPERAÇÕES DO SISTEMA ---
def cadastrar_cliente():
    print("\n--- CADASTRO DE CLIENTE ---")
    nome = input("Nome: ")
    cpf = input("CPF: ")
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO clientes (nome, cpf) VALUES (?, ?)", (nome, cpf))
        conn.commit()
        print(">> Cliente cadastrado com sucesso!")
    except Exception as e:
        print(f">> Erro ao cadastrar: {e}")
    finally:
        conn.close()

def cadastrar_produto():
    print("\n--- CADASTRO DE PRODUTO ---")
    nome = input("Nome do Produto: ")
    preco = float(input("Preço unitário: "))
    estoque = int(input("Qtd em Estoque: "))
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para facilitar a escolha
    print("\nClientes disponíveis:")
    cursor.execute("SELECT id, nome FROM clientes")
    for c in cursor.fetchall(): print(f"[{c[0]}] {c[1]}")
    
    cliente_id = int(input("\nID do Cliente: "))
    
    print("\nProdutos disponíveis:")
    cursor.execute("SELECT id, nome, preco, estoque FROM produtos")
    for p in cursor.fetchall(): print(f"[{p[0]}] {p[1]} - R${p[2]} (Estoque: {p[3]})")
    
    produto_id = int(input("\nID do Produto: "))
    quantidade = int(input("Quantidade desejada: "))
    
    # Verificar produto e estoque
    cursor.execute("SELECT preco, estoque FROM produtos WHERE id = ?", (produto_id,))
    produto = cursor.fetchone()
    
    if produto and produto[1] >= quantidade:
        total = produto[0] * quantidade
        # Registrar Venda
        cursor.execute("INSERT INTO vendas (cliente_id, produto_id, quantidade, total) VALUES (?, ?, ?, ?)",
                       (cliente_id, produto_id, quantidade, total))
        # Baixa no estoque
        cursor.execute("UPDATE produtos SET estoque = estoque - ? WHERE id = ?", (quantidade, produto_id))
        conn.commit()
        print(f"\n>> VENDA REALIZADA! Total: R${total:.2f}")
    else:
        print("\n>> ERRO: Estoque insuficiente ou produto não encontrado.")
    
    conn.close()

# --- MENU PRINCIPAL ---
def main():
    init_db()
    
    if not login():
        print("Acesso negado. Usuário ou senha incorretos.")
        return

    while True:
        print("\n" + "="*20)
        print("  MENU PRINCIPAL")
        print("="*20)
        print("1. Cadastrar Cliente")
        print("2. Cadastrar Produto")
        print("3. Realizar Venda")
        print("4. Sair")
        
        opcao = input("\nEscolha uma opção: ")
        
        if opcaoimport sqlite3
from datetime import datetime

# --- CONFIGURAÇÃO DO BANCO DE DADOS ---
def init_db():
    """Cria o banco de dados e as tabelas se não existirem."""
    conn = sqlite3.connect('sisvenda.db')
    cursor = conn.cursor()
    
    # Tabela de Usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
    # Tabela de Clientes
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf TEXT UNIQUE
        )
    ''')
    
    # Tabela de Produtos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            estoque INTEGER NOT NULL
        )
    ''')
    
    # Tabela de Vendas
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vendas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            produto_id INTEGER,
            quantidade INTEGER,
            total REAL,
            data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_id) REFERENCES clientes(id),
            FOREIGN KEY(produto_id) REFERENCES produtos(id)
        )
    ''')
    
    # Criar usuário padrão (admin / admin123)
    try:
        cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", ('admin', 'admin123'))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
        
    conn.close()
SERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para fa
# --- FUNÇÕES DE APOIO ---
def conectar():
    return sqlite3.connect('sisvenda.db')

def login():
    print("\n" + "="*20)
    print("  LOGIN SISVENDA")
    print("="*20)
    user = input("Usuário: ")
    senha = input("Senha: ")
    
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE username = ? AND password = ?", (user, senha))
    usuario = cursor.fetchone()
    conn.close()
    return usuario is not None

# --- OPERAÇÕES DO SISTEMA ---
def cadastrar_cliente():
    print("\n--- CADASTRO DE CLIENTE ---")
    nome = input("Nome: ")
    cpf = input("CPF: ")
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO clientes (nome, cpf) VALUES (?, ?)", (nome, cpf))
        conn.commit()
        print(">> Cliente cadastrado com sucesso!")
    except Exception as e:
        print(f">> Erro ao cadastrar: {e}")
    finally:
        conn.close()

def cadastrar_produto():
    print("\n--- CADASTRO DE PRODUTO ---")
    nome = input("Nome do Produto: ")
    preco = float(input("Preço unitário: "))
    estoque = int(input("Qtd em Estoque: "))
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para facilitar a escolha
    print("\nClientes disponíveis:")
    cursor.execute("SELECT id, nome FROM clientes")
    for c in cursor.fetchall(): print(f"[{c[0]}] {c[1]}")
    
    cliente_id = int(input("\nID do Cliente: "))
    
    print("\nProdutos disponíveis:")
    cursor.execute("SELECT id, nome, preco, estoque FROM produtos")
    for p in cursor.fetchall(): print(f"[{p[0]}] {p[1]} - R${p[2]} (Estoque: {p[3]})")
    
    produto_id = int(input("\nSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para faID do Produto: "))
    quantidade = int(input("Quantidade desejada: "))
    
    # Verificar produto e estoque
    cursor.execute("SELECT preco, estoque FROM produtos WHERE id = ?", (produto_id,))
    produto = cursor.fetchone()
    
    if produto and produto[1] >= quantidade:
        total = produto[0] * quantidade
        # Registrar Venda
        cursor.execute("INSERT INTO vendas (cliente_id, produto_id, quantidade, total) VALUES (?, ?, ?, ?)",
                       (cliente_id, produto_id, quantidade, total))
        # Baixa no estoque
        cursor.execute("UPDATESERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para fa produtos SET estoque = estoque - ? WHERE id = ?", (quantidade, produto_id))
        conn.commit()
        print(f"\n>> VENDA REALIZADA! Total: R${total:.2f}")
    else:
        print("\n>> ERRO: Estoque insuficiente ou produto não encontrado.")
    
    conn.close()

# --- MENU PRINCIPAL ---
def main():
    init_db()
    
    if not login():
        print("Acesso negado. Usuário ou senha incorretos.")
        return

    while True:
        print("\n" + "="*20)
        print("  MENU PRINCIPAL")
        print("="*20)
        print("1. Cadastrar Cliente")
        print("2. Cadastrar Produto")
        print("3. Realizar Venda")
        print("4. Sair")
        
        opcao = input("\nEscolha uma opção: ")
        
        if opcao == '1':
            cadastrar_cliente()
        elif opcao == '2':
            cadaimport sqlite3
from datetime import datetime

# --- CONFIGURAÇÃO DO BANCO DE DADOS ---
def init_db():
    """Cria o banco de dados e as tabelas se não existirem."""
    conn = sqlite3.connect('sisvenda.db')
    cursor = conn.cursor()
    
    # Tabela de Usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
    # Tabela de Clientes
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf TEXT UNIQUE
        )
    ''')
    
    # Tabela de Produtos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            estoque INTEGER NOT NULL
        )
    ''')
    
    # Tabela de Vendas
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vendas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            produto_id INTEGER,
            quantidade INTEGER,
            total REAL,
            data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_id) REFERENCES clientes(id),
            FOREIGN KEY(produto_id) REFERENCES produtos(id)
        )
    ''')
    
    # Criar usuário padrão (admin / admin123)
    try:
        cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", ('admin', 'admin123'))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
        
    conn.close()
SERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para fa
# --- FUNÇÕES DE APOIO ---
def conectar():
    return sqlite3.connect('sisvenda.db')

def login():
    print("\n" + "="*20)
    print("  LOGIN SISVENDA")
    print("="*20)
    user = input("Usuário: ")
    senha = input("Senha: ")
    
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE username = ? AND password = ?", (user, senha))
    usuario = cursor.fetchone()
    conn.close()
    return usuario is not None

# --- OPERAÇÕES DO SISTEMA ---
def cadastrar_cliente():
    print("\n--- CADASTRO DE CLIENTE ---")
    nome = input("Nome: ")
    cpf = input("CPF: ")
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO clientes (nome, cpf) VALUES (?, ?)", (nome, cpf))
        conn.commit()
        print(">> Cliente cadastrado com sucesso!")
    except Exception as e:
        print(f">> Erro ao cadastrar: {e}")
    finally:
        conn.close()

def cadastrar_produto():
    print("\n--- CADASTRO DE PRODUTO ---")
    nome = input("Nome do Produto: ")
    preco = float(input("Preço unitário: "))
    estoque = int(input("Qtd em Estoque: "))
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para facilitar a escolha
    print("\nClientes disponíveis:")
    cursor.execute("SELECT id, nome FROM clientes")
    for c in cursor.fetchall(): print(f"[{c[0]}] {c[1]}")
    
    cliente_id = int(input("\nID do Cliente: "))
    
    print("\nProdutos disponíveis:")
    cursor.execute("SELECT id, nome, preco, estoque FROM produtos")
    for p in cursor.fetchall(): print(f"[{p[0]}] {p[1]} - R${p[2]} (Estoque: {p[3]})")
    
    produto_id = int(input("\nSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para faID do Produto: "))
    quantidade = int(input("Quantidade desejada: "))
    
    # Verificar produto e estoque
    cursor.execute("SELECT preco, estoque FROM produtos WHERE id = ?", (produto_id,))
    produto = cursor.fetchone()
    
    if produto and produto[1] >= quantidade:
        total = produto[0] * quantidade
        # Registrar Venda
        cursor.execute("INSERT INTO vendas (cliente_id, produto_id, quantidade, total) VALUES (?, ?, ?, ?)",
                       (cliente_id, produto_id, quantidade, total))
        # Baixa no estoque
        cursor.execute("UPDATESERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para fa produtos SET estoque = estoque - ? WHERE id = ?", (quantidade, produto_id))
        conn.commit()
        print(f"\n>> VENDA REALIZADA! Total: R${total:.2f}")
    else:
        print("\n>> ERRO: Estoque insuficiente ou produto não encontrado.")
    
    conn.close()import sqlite3
from datetime import datetime

# --- CONFIGURAÇÃO DO BANCO DE DADOS ---
def init_db():
    """Cria o banco de dados e as tabelas se não existirem."""
    conn = sqlite3.connect('sisvenda.db')
    cursor = conn.cursor()
    
    # Tabela de Usuários
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    ''')
    
    # Tabela de Clientes
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf TEXT UNIQUE
        )
    ''')
    
    # Tabela de Produtos
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS produtos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            preco REAL NOT NULL,
            estoque INTEGER NOT NULL
        )
    ''')
    
    # Tabela de Vendas
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS vendas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER,
            produto_id INTEGER,
            quantidade INTEGER,
            total REAL,
            data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(cliente_id) REFERENCES clientes(id),
            FOREIGN KEY(produto_id) REFERENCES produtos(id)
        )
    ''')
    
    # Criar usuário padrão (admin / admin123)
    try:
        cursor.execute("INSERT INTO usuarios (username, password) VALUES (?, ?)", ('admin', 'admin123'))
        conn.commit()
    except sqlite3.IntegrityError:
        pass
        
    conn.close()
SERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para fa
# --- FUNÇÕES DE APOIO ---
def conectar():
    return sqlite3.connect('sisvenda.db')

def login():
    print("\n" + "="*20)
    print("  LOGIN SISVENDA")
    print("="*20)
    user = input("Usuário: ")
    senha = input("Senha: ")
    
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM usuarios WHERE username = ? AND password = ?", (user, senha))
    usuario = cursor.fetchone()
    conn.close()
    return usuario is not None

# --- OPERAÇÕES DO SISTEMA ---
def cadastrar_cliente():
    print("\n--- CADASTRO DE CLIENTE ---")
    nome = input("Nome: ")
    cpf = input("CPF: ")
    try:
        conn = conectar()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO clientes (nome, cpf) VALUES (?, ?)", (nome, cpf))
        conn.commit()
        print(">> Cliente cadastrado com sucesso!")
    except Exception as e:
        print(f">> Erro ao cadastrar: {e}")
    finally:
        conn.close()

def cadastrar_produto():
    print("\n--- CADASTRO DE PRODUTO ---")
    nome = input("Nome do Produto: ")
    preco = float(input("Preço unitário: "))
    estoque = int(input("Qtd em Estoque: "))
    conn = conectar()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para facilitar a escolha
    print("\nClientes disponíveis:")
    cursor.execute("SELECT id, nome FROM clientes")
    for c in cursor.fetchall(): print(f"[{c[0]}] {c[1]}")
    
    cliente_id = int(input("\nID do Cliente: "))
    
    print("\nProdutos disponíveis:")
    cursor.execute("SELECT id, nome, preco, estoque FROM produtos")
    for p in cursor.fetchall(): print(f"[{p[0]}] {p[1]} - R${p[2]} (Estoque: {p[3]})")
    
    produto_id = int(input("\nSERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para faID do Produto: "))
    quantidade = int(input("Quantidade desejada: "))
    
    # Verificar produto e estoque
    cursor.execute("SELECT preco, estoque FROM produtos WHERE id = ?", (produto_id,))
    produto = cursor.fetchone()
    
    if produto and produto[1] >= quantidade:
        total = produto[0] * quantidade
        # Registrar Venda
        cursor.execute("INSERT INTO vendas (cliente_id, produto_id, quantidade, total) VALUES (?, ?, ?, ?)",
                       (cliente_id, produto_id, quantidade, total))
        # Baixa no estoque
        cursor.execute("UPDATESERT INTO produtos (nome, preco, estoque) VALUES (?, ?, ?)", (nome, preco, estoque))
    conn.commit()
    conn.close()
    print(">> Produto cadastrado!")

def realizar_venda():
    print("\n--- NOVA VENDA ---")
    conn = conectar()
    cursor = conn.cursor()
    
    # Listar Clientes e Produtos para fa produtos SET estoque = estoque - ? WHERE id = ?", (quantidade, produto_id))
        conn.commit()
        print(f"\n>> VENDA REALIZADA! Total: R${total:.2f}")
    else:
        print("\n>> ERRO: Estoque insuficiente ou produto não encontrado.")
    
    conn.close()

# --- MENU PRINCIPAL ---
def main():
    init_db()
    
    if not login():
        print("Acesso negado. Usuário ou senha incorretos.")
        return

    while True:
        print("\n" + "="*20)
        print("  MENU PRINCIPAL")
        print("="*20)
        print("1. Cadastrar Cliente")
        print("2. Cadastrar Produto")
        print("3. Realizar Venda")
        print("4. Sair")
        
        opcao = input("\nEscolha uma opção: ")
        
        if opcao == '1':
            cadastrar_cliente()
        elif opcao == '2':
            cadastrar_produto()
        elif opcao == '3':
            realizar_venda()
        elif opcao == '4':
            print("Encerrando sistema...")
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    main()

# --- MENU PRINCIPAL ---
def main():
    init_db()
    
    if not login():
        print("Acesso negado. Usuário ou senha incorretos.")
        return

    while True:
        print("\n" + "="*20)
        print("  MENU PRINCIPAL")
        print("="*20)
        print("1. Cadastrar Cliente")
        print("2. Cadastrar Produto")
        print("3. Realizar Venda")
        print("4. Sair")
        
        opcao = input("\nEscolha uma opção: ")
        
        if opcao == '1':
            cadastrar_cliente()
        elif opcao == '2':
            cadastrar_produto()
        elif opcao == '3':
            realizar_venda()
        elif opcao == '4':
            print("Encerrando sistema...")
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    main()strar_produto()
        elif opcao == '3':
            realizar_venda()
        elif opcao == '4':
            print("Encerrando sistema...")
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    main() == '1':
            cadastrar_cliente()
        elif opcao == '2':
            cadastrar_produto()
        elif opcao == '3':
            realizar_venda()
        elif opcao == '4':
            print("Encerrando sistema...")
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    main()